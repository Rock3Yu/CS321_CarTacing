from array import array
import sys
import random
import pygame
# from model.PettingZoo.pettingzoo.mpe.simple.simple import Scenario 
sys.path.append("D:\Source\Project_Big\model\PettingZoo\pettingzoo\mpe\_mpe_utils")
sys.path.append("D:\Source\Project_Big\model\PettingZoo\pettingzoo\mpe")
#from email import policy
import policy 
import simple_env_mine as env_mine
from police_criminal import police_criminal as pc
import numpy as np

if __name__=='__main__':
    first=pc.exchange()
    filename = '../_mpe_utils/maps/first.txt'
    # file=open(filename,'r')
    pygame.init()
    env=pc.raw_env()

    # first.generator(filename,100)
    env.reset()
        # print( [entity.state.p_pos for entity in env.world.entities]) 
    cnt=0
    x,y=0,0
    for agent in env.agent_iter(600):
        env.render()
        observation, reward, done, info = env.last()
        # if cnt==0 or cnt%10==0 or  cnt==599:
        #     input()
        if cnt%30 ==0:
            x,y=random.random()*2-1,random.random()*2-1
            # action = []
        action=np.array([0.,max(x,0.),max(-x,0.),max(y,0.),max(-y,0.)])
        env.step(action)
        cnt+=1
    # pygame.quit()
    env.close()

    